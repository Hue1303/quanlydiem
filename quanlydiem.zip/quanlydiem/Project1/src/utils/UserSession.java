package utils;

public class UserSession {
    public static String taiKhoan = "";
    public static String hoTen = "";
    public static String vaiTro = "";
    public static String chuyenMon = "";
    public static void clear() {
        taiKhoan = "";
        hoTen = "";
        vaiTro = "";
        chuyenMon = "";
    }
}